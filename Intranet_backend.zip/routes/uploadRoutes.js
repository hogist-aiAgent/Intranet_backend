const multer = require('multer');
const express = require('express');
const { uploadPdf } = require('../controllers/uploadControllers'); // CommonJS require
const router = express.Router();

const storage = multer.memoryStorage();
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype !== 'application/pdf') {
      return cb(new Error('Only PDF files are allowed!'));
    }
    cb(null, true);
  }
});

router.post('/upload', upload.single('file'), uploadPdf);

module.exports = router; // Use module.exports for CommonJS
